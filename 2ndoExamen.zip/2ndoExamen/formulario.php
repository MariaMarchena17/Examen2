<?php

  $Nombre = $_POST['Nombre'];
  $Correo = $_POST['Correo'];
  $Telefono = $_POST['Telefono'];
  $Mensaje = $_POST['Mensaje'];


    echo $Nombre;
    echo $Correo;
    echo $Telefono;
    echo $Mensaje;
    

?>
